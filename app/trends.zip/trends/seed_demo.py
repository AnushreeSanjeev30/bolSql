"""
Demo Data Seeder
Generates realistic Kirana transaction data for testing all 13 trends.

Run: python app/trends/seed_demo.py
"""

import sqlite3
import random
from datetime import datetime, timedelta

ITEMS = [
    ("Atta",         22, 18),   # name, sell_price, cost_price
    ("Chawal",       55, 42),
    ("Dal",          90, 70),
    ("Milk",         28, 22),
    ("Maggi",        14, 10),
    ("Bread",        40, 30),
    ("Butter",       55, 42),
    ("Chai Patti",   280, 210),
    ("Biscuit",      20, 14),
    ("Cold Drink",   40, 28),
    ("Ice Cream",    50, 35),
    ("Pickle",       60, 45),
    ("Sauce",        80, 58),
    ("Namak",        20, 14),
    ("Oil",          130, 100),
]

CUSTOMERS = [f"C{str(i).zfill(3)}" for i in range(1, 20)]

FESTIVAL_WINDOWS = {
    "diwali": ("2024-11-01", "2024-11-05"),
    "holi":   ("2024-03-24", "2024-03-26"),
}

SEASONAL_BOOST = {
    4: ["Cold Drink", "Ice Cream"],   # April (summer)
    5: ["Cold Drink", "Ice Cream"],
    6: ["Cold Drink", "Ice Cream"],
    7: ["Chai Patti", "Maggi"],       # July (monsoon)
    8: ["Chai Patti", "Maggi"],
    12: ["Chai Patti", "Namak"],      # December (winter)
    1:  ["Chai Patti"],
}


def seed(db_path: str = "kirana.db", days_back: int = 180):
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Ensure tables exist
    cur.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            quantity REAL DEFAULT 0,
            cost_price REAL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT,
            quantity REAL,
            price REAL,
            sold_at DATETIME,
            customer_id TEXT
        )
    """)

    # Seed inventory
    for name, sell, cost in ITEMS:
        stock = random.randint(5, 200)
        cur.execute("""
            INSERT OR IGNORE INTO inventory(name, quantity, cost_price)
            VALUES (?, ?, ?)
        """, (name, stock, cost))

    print(f"  ✅ Inventory seeded with {len(ITEMS)} items")

    # Seed transactions (180 days of history)
    now = datetime.now()
    tx_count = 0

    for day_offset in range(days_back, 0, -1):
        day = now - timedelta(days=day_offset)
        month = day.month

        # Peak hours: 9-11 AM and 6-8 PM
        rush_hours = list(range(9, 12)) + list(range(18, 21))
        slow_hours = list(range(7, 9)) + list(range(12, 18))
        all_hours = rush_hours * 3 + slow_hours

        # Number of transactions per day (weekend boost)
        base_tx = 40 if day.weekday() >= 5 else 25
        n_tx = random.randint(base_tx - 5, base_tx + 15)

        for _ in range(n_tx):
            hour = random.choice(all_hours)
            minute = random.randint(0, 59)
            ts = day.replace(hour=hour, minute=minute, second=random.randint(0, 59))

            # Seasonal boost
            boosted = SEASONAL_BOOST.get(month, [])
            pool = ITEMS.copy()
            for i, (name, sell, cost) in enumerate(pool):
                if name in boosted:
                    pool.extend([(name, sell, cost)] * 3)  # 4x weight

            item_name, sell_price, _ = random.choice(pool)
            qty = random.randint(1, 5)

            # Customer assignment (70% known customers)
            customer = random.choice(CUSTOMERS) if random.random() < 0.7 else None

            cur.execute("""
                INSERT INTO transactions(item_name, quantity, price, sold_at, customer_id)
                VALUES (?, ?, ?, ?, ?)
            """, (item_name, qty, sell_price, ts.strftime("%Y-%m-%d %H:%M:%S"), customer))
            tx_count += 1

        # Festival boost
        day_str = day.strftime("%Y-%m-%d")
        for fest, (start, end) in FESTIVAL_WINDOWS.items():
            if start <= day_str <= end:
                for _ in range(20):
                    item_name, sell_price, _ = random.choice(ITEMS)
                    qty = random.randint(2, 10)
                    cur.execute("""
                        INSERT INTO transactions(item_name, quantity, price, sold_at, customer_id)
                        VALUES (?, ?, ?, ?, ?)
                    """, (item_name, qty, sell_price,
                          day.strftime("%Y-%m-%d %H:%M:%S"), random.choice(CUSTOMERS)))
                    tx_count += 1

    conn.commit()
    conn.close()
    print(f"  ✅ {tx_count} transactions seeded across {days_back} days")
    print("  ✅ Demo data ready! All 13 trends can now be tested.")


if __name__ == "__main__":
    seed()
